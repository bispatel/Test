package com.calmis.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.calmis.beans.AuthenticationResponse;
import com.calmis.beans.UserInfo;
import com.calmis.common.Constant;
import com.calmis.service.AuthenticationService;
import com.calmis.service.UserService;
import com.calmis.util.JwtUtil;

@RestController
public class AuthenticationController implements Constant {
	private static Logger LOG = LoggerFactory.getLogger(AuthenticationController.class);

	@Autowired
	UserService userService;

	@Autowired
	private JwtUtil jwtTokenUtil;

	@Autowired
	private AuthenticationService userDetailsService;

	@RequestMapping({ "/hello" })
	public String firstPage() {
		return "Hello World";
	}

	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	public ResponseEntity<?> createAuthenticationToken(@RequestBody UserInfo authReq) throws Exception {
		LOG.info("Inside createAuthenticationToken method" );
		final UserDetails userDetails = userDetailsService.loadUserByUsername(authReq.getUsername());
		final String jwt = jwtTokenUtil.generateToken(userDetails.getUsername());
		return ResponseEntity.ok(new AuthenticationResponse(jwt));		
	}

}