package com.calmis.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.calmis.beans.ResponseEntity;
import com.calmis.beans.UserInfo;
import com.calmis.service.UserService;
import com.calmis.util.Validations;

@RestController
@RequestMapping("/api")
public class UserController {

	private static Logger LOG = LoggerFactory.getLogger(UserController.class);

	@Autowired
	UserService userService;

	@RequestMapping(value = "/test", method = RequestMethod.GET)
	public String getTest() {
		return "Testing API";
	}

	/**
	 * This method is used to validate the user based on the input parameter
	 * 
	 * @param userId
	 * @return
	 */
	@RequestMapping(value = "validateUser/{userId}", method = RequestMethod.GET)
	public String validateUser(@PathVariable("userId") String userId) {
		LOG.info("Inside validateUser");
		String output = Validations.isValidUser(userId);
		if (output.equals("")) {
			output = userService.validate(userId);
		}
		return output;
	}

	@RequestMapping(value = "checkStatus/{userId}", method = RequestMethod.GET)
	public String checkStatus(@PathVariable("userId") String userId) {
		LOG.info("Inside checkStatus");
		return userService.checkStatus(userId);
	}

	@RequestMapping(value = "getUnitCode", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String getUnitCodeByUserId(@RequestBody UserInfo user) {
		LOG.info("Inside getUnitCode");
		return userService.getUnitCode(user);
	}

	@RequestMapping(value = "fetchUnit", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity fetchUnitCode(@RequestBody UserInfo user) {
		LOG.info("Inside fetchUnitCode");
		return userService.getUnitDetails(user);
	}

	@RequestMapping(value = "login", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity login(@RequestBody UserInfo user) {
		LOG.info("Inside login");
		return userService.login(user);
	}
	
	@RequestMapping(value = "login", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity fetchUnitCodeDetails(@RequestBody UserInfo user) {
		LOG.info("Inside fetchUnitCodeDetails");
		return userService.fetchUnitCodeDetails(user);
	}

}